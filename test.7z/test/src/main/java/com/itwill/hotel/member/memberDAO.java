package com.itwill.hotel.member;

public class memberDAO {

}
